#finterm

#Student Name: Ng Chun Hei Maxx
#Student Id: 41147039s

**This finterm consists of 6 tasks**

**use these**
###fin01
```console
make fin01
```

###fin02
```console
make fin02
```

###fin03
```console
make fin03
```

###fin04
```console
make fin04
```
