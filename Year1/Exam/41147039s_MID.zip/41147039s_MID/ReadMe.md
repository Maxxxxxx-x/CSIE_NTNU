#Midterm

#Student Name: Ng Chun Hei Maxx
#Student Id: 41147039s

**This midterm consists of 6 tasks, resulting in 5 executable C file(s) and 1 PDF file**

**Please enter the following command(s) in the folder directory in order to execute the program**
###mid01
```console
make mid01
```

###mid02
```console
make mid02
```

###mid03
```console
make mid03
```

###mid04
```console
make mid04
```

###mid05
```console
make mid05
```